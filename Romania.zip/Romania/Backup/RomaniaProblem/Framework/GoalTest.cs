using System;

namespace Framework
{
	/// <summary>
	/// Summary description for GoalTest.
	/// </summary>
	public interface GoalTest
	{
		bool isGoalState(Object state);
	}
}
