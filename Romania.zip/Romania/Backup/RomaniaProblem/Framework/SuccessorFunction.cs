using System;
using System.Collections;

namespace Framework
{
	/// <summary>
	/// Summary description for SuccessorFunction.
	/// </summary>
	public interface SuccessorFunction 
	{

		ArrayList getSuccessors(Object state);

	}
}
