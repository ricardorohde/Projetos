using System;

namespace Framework
{
	/// <summary>
	/// Summary description for HeuristicFunction.
	/// </summary>
	public interface HeuristicFunction 
	{

		int getHeuristicValue(Object state);

	}
}
