# DigitalPersonaDelphi
Exemplo Delphi de um aplicativo que integra com leitor biométrico Digital Persona