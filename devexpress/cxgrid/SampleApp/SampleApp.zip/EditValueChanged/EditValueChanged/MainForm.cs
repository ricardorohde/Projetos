using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using DevExpress.XtraEditors;

namespace EditValueChanged
{
    public partial class MainForm : XtraForm
    {
        private DataTable dtblValues = new DataTable();

        public MainForm()
        {
            InitializeComponent();

            dtblValues.Columns.Add("ValuePK", typeof(int));
            dtblValues.Columns.Add("Values", typeof(string));
            for (int iIndex = 1; iIndex < 4; iIndex++)
                dtblValues.Rows.Add(new object[] { iIndex, "Value" + iIndex });

            rletMainFormValues.DataSource = dtblValues;
            rletMainFormValues.DisplayMember = "Values";
            rletMainFormValues.ValueMember = "ValuePK";
        }

        private void bbiMainFormClose_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            this.Close();
        }

        private void MainForm_Shown(object sender, EventArgs e)
        {
            beiMainFormValues.BeginUpdate();
            try
            {
                beiMainFormValues.EditValue = dtblValues.Rows[0]["ValuePK"].ToString();
            }
            finally
            {
                beiMainFormValues.EndUpdate();
            }
        }

        private void rletMainFormValues_EditValueChanging(object sender, DevExpress.XtraEditors.Controls.ChangingEventArgs e)
        {
            bool bCancel = false;
            if ((barCheckItem1.Checked) && (XtraMessageBox.Show("Allow Change", "Sample", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No))
                bCancel = true;
            e.Cancel = bCancel;
            //beiMainFormValues.EditValue = e.NewValue;
        }

        private void rletMainFormValues_EditValueChanged(object sender, EventArgs e)
        {
            XtraMessageBox.Show("Edit value changed is fired");
        }

        private void rletMainFormValues_CloseUp(object sender, DevExpress.XtraEditors.Controls.CloseUpEventArgs e)
        {
            if (barCloseup.Checked) XtraMessageBox.Show("Closeup");
            e.AcceptValue = true;
        }

    }
}